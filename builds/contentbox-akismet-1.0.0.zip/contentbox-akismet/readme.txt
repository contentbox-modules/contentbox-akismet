********************************************************************************
Copyright 2009 ColdBox Framework by Luis Majano and Ortus Solutions, Corp
www.coldboxframework.com | www.luismajano.com | www.ortussolutions.com
********************************************************************************

Author 	 :	Luis Majano
Description :

This module allows you to add Akismet capabilities to your ContentBox installation.
You will need an Akismet API key in order to use this module.

For more information visit: http://www.akismet.com

======================================================================
CHANGELOG
======================================================================

Version 1.0
# Initial Release